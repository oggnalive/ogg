Invoke-WebRequest -Uri "https://dl.walletbuilders.com/download?customer=551dbd8088fa7c503397382ff323cad009185e9b7abf405f86&filename=oggnalive-qt-windows.zip" -OutFile "$HOME\Downloads\oggnalive-qt-windows.zip"

Start-Sleep -s 15

Expand-Archive -LiteralPath "$HOME\Downloads\oggnalive-qt-windows.zip" -DestinationPath "$HOME\Desktop\oggnalive"

$ConfigFile = "rpcuser=rpc_oggnalive
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=127.0.0.1
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node3.walletbuilders.com"

New-Item -Path "$env:appdata" -Name "oggnalive" -ItemType "directory"
New-Item -Path "$env:appdata\oggnalive" -Name "oggnalive.conf" -ItemType "file" -Value $ConfigFile

$MineBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
echo Press [CTRL+C] to stop mining.
:begin
 for /f %%i in ('oggnalive-cli.exe getnewaddress') do set WALLET_ADDRESS=%%i
 oggnalive-cli.exe generatetoaddress 1 %WALLET_ADDRESS%
goto begin"

New-Item -Path "$HOME\Desktop\oggnalive" -Name "mine.bat" -ItemType "file" -Value $MineBat

Start-Process "$HOME\Desktop\oggnalive\oggnalive-qt.exe"

Start-Sleep -s 15

Set-Location "$HOME\Desktop\oggnalive\"

$AddressBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
oggnalive-cli.exe -named createwallet wallet_name=""
del %0"

New-Item -Path "$HOME\Desktop\oggnalive" -Name "create_address.bat" -ItemType "file" -Value $AddressBat
Start-Process "create_address.bat";
                
Start-Sleep -s 15

Start-Process "mine.bat"